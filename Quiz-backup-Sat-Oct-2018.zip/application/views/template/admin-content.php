<?php $this->load->view('template/admin-header');?>
<?php $this->load->view($page);?>
<?php $this->load->view('template/admin-footer');?> 
