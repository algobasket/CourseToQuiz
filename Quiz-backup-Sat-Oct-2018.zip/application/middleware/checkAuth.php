<?php
trait checkAuth{
   function isUserLoggedIn(){
     echo "ok";
   }
}
 ?>
