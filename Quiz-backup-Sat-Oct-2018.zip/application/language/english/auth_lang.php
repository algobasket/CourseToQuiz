<?php
$lang['loginError'] = '<div class="alert alert-danger">Invalid Login</div>';
