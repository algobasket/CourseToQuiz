<?php
class Payment_model extends CI_Model{
   
}
 ?>
