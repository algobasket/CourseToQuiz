<?php
class Setting_model extends CI_Model{

  function maintainance(){
    
  }

  function payment(){

  }

}
 ?>
