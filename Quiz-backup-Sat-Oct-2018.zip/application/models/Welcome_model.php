<?php
class Welcome_model extends CI_Model{

   function __construct(){
     parent::__construct();
   }

   // Get User Course
    function myCourse(){
       
    }

    // Get Account Info
    function myAccount(){

    }

   // Get Setting
    function mySetting(){

    }




}
 ?>
