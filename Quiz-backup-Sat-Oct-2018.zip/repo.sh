echo "Start Bitbucket"
cd ../Quiz-Bitbucket
rm -rf application
rm -rf assets
rm -rf system
rm background.png
rm index.php
rm README.md
rm .htaccess
echo "Start Github"
cd ../
cd Quiz-Git
rm -rf application
rm -rf assets
rm -rf system
rm background.png
rm index.php
rm README.md
rm .htaccess
echo "Update Both Git & Bitbucket"
cd ../Quiz
cp -r ./* ../Quiz-Bitbucket
cp -r ./* ../Quiz-Git
rm ../Quiz-Git/repo.sh
rm ../Quiz-Bitbucket/repo.sh
